#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

#moj_import <minecraft:materione_text_effects.glsl>

void main() {
    // attributes are read-only: the hooks animate a local copy
    vec3 mtrPosition = Position;
    materionePreTransform(mtrPosition);

    gl_Position = ProjMat * ModelViewMat * vec4(mtrPosition, 1.0);

    vertexDistance = fog_distance(mtrPosition, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    materionePostTransform(mtrPosition);
}
